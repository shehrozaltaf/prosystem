<div class="sidenav-overlay"></div>
<div class="drag-target"></div>